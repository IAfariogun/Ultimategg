package com.example.ultimategg

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import androidx.core.view.isVisible
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {

    private lateinit var btnSmashUltimate: Button
    private lateinit var btnSmash4: Button
    private lateinit var btnSmashIncoming: Button
    private lateinit var userList: ArrayList<User>
    private lateinit var adapter: UserAdapter
    private lateinit var mAuth: FirebaseAuth
    private lateinit var mDbRef: DatabaseReference
    private lateinit var btnAddGame: Button
    private lateinit var addSign: ImageView



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mAuth = FirebaseAuth.getInstance() //initialize Firebase Authentication

        userList = ArrayList()
        adapter = UserAdapter(this,userList)

        btnSmashUltimate = findViewById(R.id.btnUltimate)
        btnSmash4 = findViewById(R.id.btnSmash4)
        btnSmashIncoming = findViewById(R.id.btnSmashIncoming)
        btnAddGame = findViewById(R.id.btnAddGame)
        addSign = findViewById(R.id.addSign)



        mDbRef = FirebaseDatabase.getInstance().getReference()
        var uid = mAuth.currentUser?.uid


        if (uid != null) {
            mDbRef.child("admin").child(uid).child("role").get().addOnSuccessListener {
                Log.i("firebase", "Got role ${it.value}")
                if (it.value != "Admin") {
                    btnAddGame.visibility = View.GONE
                    addSign.visibility = View.GONE
                }
            }.addOnFailureListener{
                Log.e("firebase", "Error getting data", it)
            }
        }




        btnSmashUltimate.setOnClickListener {
            val intent = Intent(this, Chat::class.java)
            finish()
            startActivity(intent)
        }

        btnSmash4.setOnClickListener {
            /* Will redirect to the smash 4 users chat
            val intent = Intent(this, Chat::class.java)
            startActivity(intent)
             */
        }

        btnSmashIncoming.setOnClickListener {
            /* Will redirect to a new smash users chat
            val intent = Intent(this, Chat::class.java)
            startActivity(intent)
             */
        }



    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu,menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        if(item.itemId == R.id.logout){
            // write the login for logout
            mAuth.signOut()
            finish()
            return true
        }
        return true
    }




}