package com.example.ultimategg

import android.os.health.UidHealthStats
import android.provider.ContactsContract

class User {
    var username: String? = null
    var email: String? = null
    var uid: String? = null
    var role: String? = null

    constructor(){}

    constructor(username: String?, email: String?, uid: String?, role: String?){
        this.username = username
        this.email = email
        this.uid = uid
        this.role = role

    }
}